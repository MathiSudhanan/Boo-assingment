const Profile = require("../models/profile.model");
const Comment = require("../models/comment.model");

const mongoose = require("mongoose");

exports.getAllComments = async(req,res)=>{
  try {
    const comments = await Comment.find();
    res.status(200).json(comments);
    
  } catch (error) {
    res.status(404).json({ mesage: error.message });
    
  }
}


exports.getComments = async (req, res) => {
  try {
    const { profileId } = req.params;
    
    const {sortBy,mtbi,enneagram,zodiac} = req.query;
    const filters = [];
    if(mtbi)
    {
      filters.push({"mtbi": mtbi})
    }
    if(enneagram)
    {
      filters.push({"enneagram": enneagram})
    }
    if(zodiac)
    {
      filters.push({"zodiac": zodiac})
    }
    let query = GetAggregateQuery(profileId, sortBy, filters);

    const comments = await Comment.aggregate(query);
    
    res.status(200).json(comments);

  } catch (error) {
    res.status(404).json({ mesage: error.message });
  }
};

exports.addComment = async (req, res) => {
  let post = req.body;
  const { profileId, loginId, comment } = post;

  comment.profile = mongoose.Types.ObjectId(profileId);
  comment.commentedBy= mongoose.Types.ObjectId(loginId);
  const commentNew = new Comment(comment);
  try {
    await commentNew.save();

    const profile = await Profile.findByIdAndUpdate(
      profileId,
      {
        $push: { comments: commentNew._id },
      },
      { new: true, useFindAndModify: false }
    );

  

    res.status(201).json(profile.populate('comments'));
  } catch (error) {
    res.status(409).json({ mesage: error.message });
  }
};

const GetAggregateQuery = (profileId, sortBy, filters) => {
  let query = [];
  let filterQuery ={'profile': mongoose.Types.ObjectId(profileId)};
  if(filters && filters.length)
  {
    const expandArrayToObj = Object.assign({},...filters);
    
    filterQuery = {...filterQuery,...expandArrayToObj}
  }
  query.push({
    $match: filterQuery 
  });

  query.push({
    $lookup: {
      from: 'profiles',
      localField: 'commentedBy',
      foreignField: '_id',
      as: 'commentor'
    }
  });

  query.push({$unwind:'$commentor'});

  
  query.push({
    $project:{
      "title": 1,
		"comment": 1,
		"mtbi": 1,
		"enneagram": 1,
		"zodiac": 1,
    "commentor.name":1,
    "commentor.image":1,
    "likes":1,
    "createdDate":1
    }
  });

  query.push({
    "$group": {
      "_id": "$_id",
      "title": { $first: "$title" },
      "comment": { $first: "$comment" },
      "mtbi": { $first: "$mtbi" },
      "enneagram": { $first: "$enneagram" },
      "zodiac": { $first: "$zodiac" },
      "createdDate": {$first:"$createdDate"},
      "commentedBy": { $first: "$commentor.name" },
      "commentedByImage": { $first: "$commentor.image" },
      "likesCount": {
        "$sum": {
          "$size": "$likes"
        }
      }
    }
  });


  if (sortBy) {
    if (sortBy === "recent") {
      let sort = {};
      sort['createdDate'] = -1;
      query.push({ $sort: sort });
    }
    else if (sortBy === "best") {
      let sort = {};
      sort['likesCount'] = -1;
      query.push({ $sort: sort });
    }
  }

 
  return query;
}

