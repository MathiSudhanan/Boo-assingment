const Profile = require("../models/profile.model");
// const Comment = require("../models/comment.model");
// const Like = require("../models/like.model");

exports.getProfiles = async (req, res) => {
  try {
    const profiles = await Profile.find();
    res.status(200).json(profiles);
  } catch (error) {
    res.status(404).json({ mesage: error.message });
  }
};

exports.getProfileById = async (req, res) => {
  const { id } = req.params;
  try {
    const profile = await Profile.findOne({ _id: id });
    res.status(200).json(profile);
  } catch (error) {
    res.status(404).json({ mesage: error.message });
  }
};

exports.createProfile = async (req, res) => {
  let post = req.body;

  const profile = new Profile(post);
  try {
    await profile.save();
    res.status(201).json(profile);
  } catch (error) {
    res.status(409).json({ mesage: error.message });
  }
};
