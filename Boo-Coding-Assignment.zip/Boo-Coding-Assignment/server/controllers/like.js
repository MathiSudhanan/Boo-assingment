const mongoose = require("mongoose");

const Profile = require("../models/profile.model");
const Comment = require("../models/comment.model");
const Like = require("../models/like.model");

exports.getLikes = async (req, res) => {
    try {
      const likes = await Like.find().populate('comment').populate('likedBy');
      res.status(200).json(likes);
    } catch (error) {
      res.status(404).json({ mesage: error.message });
    }
  };


exports.upsertLike = async (req, res) => {
    let post = req.body;
  const { commentId, loginId, like } = post;

  like.comment = mongoose.Types.ObjectId(commentId);
  like.likedBy= mongoose.Types.ObjectId(loginId);
  
    const likeObj = new Like(like);
    try {
      await likeObj.save();
      res.status(201).json(likeObj);
    } catch (error) {
      res.status(409).json({ mesage: error.message });
    }
  };
  