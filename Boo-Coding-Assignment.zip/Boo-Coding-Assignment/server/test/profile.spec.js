const { assert } = require("chai");

let should = require('chai').should(),
  expect = require('chai').expect,
  supertest = require('supertest'),
  api = supertest('http://localhost:3000')
  

  describe('Profile api test', function () {
    
  
    it('should return a 200 response', function (done) {
      api
        .get(`/api/profile`)
        
        .expect(200)
        .expect('Content-Type', 'application/json; charset=utf-8')       
        .end(function(err, res) {
          if (err) throw err;
          
          assert.equal(res.body.length,3)
          done()
        });
        
    })

    it('Should return valid data for added profile',function(done){

      const data={
        "name": "Mega",
        "description": "Adolph Larrue Martinez III.",
        "mbti": "ISFJ",
        "enneagram": "9w3",
        "variant": "sp/so",
        "tritype": 725,
        "socionics": "SEE",
        "sloan": "RCOEN",
        "psyche": "FEVL",
        "image": "https://soulverse.boo.world/images/3.png",
        "comments": []
    };
      api
        .post('/api/profile')
        .send(data)       
        .set('Accept', 'application/json')
        .expect(201)
        .end(function(err, res){
              if (err || !res.ok) {
                throw err;
              } else {
                
                assert(res.body.hasOwnProperty('name'))
                
                assert.equal(res.body.name,data.name)
              }
              done()
          });
          
    })
  
    it('should return a 404 response for invalid Profile ID', function (done) {
      api
        .get('/api/profile/hello')
        .set('Accept', 'application/json')
        .expect(404, done)
    })

    it('should return a 409 response for invalid insert', function (done) {
      let data = {"test":"test"};
      api
      .post('/api/profile')
      .send(data)       
      .set('Accept', 'application/json')
      
        .expect(409, done)
    })
  })