const { assert } = require("chai");

let should = require('chai').should(),
  expect = require('chai').expect,
  supertest = require('supertest'),
  api = supertest('http://localhost:3000')

  const formatDate= (date) => {
    return date.toISOString().slice(0,10);
  }


  describe('Comment api test', function () {
    
    var profileId ="";
    before(function(done){
        
        api
        .get(`/api/profile`)
        .expect(200)
        .expect('Content-Type', 'application/json; charset=utf-8')  
        .end(function(err, res) {
          if (err) throw err;
        
          profileId = res.body[0]._id;
          
          done()
        });
        
        

    })
  
    it('should return a 200 response for get request', function (done) {
      api
        .get(`/api/comment`)
        
        .expect(200)
        .expect('Content-Type', 'application/json; charset=utf-8')       
        .end(function(err, res) {
          if (err) throw err;
         
          assert.equal(res.body.length,2)
          done()
        });
        
    });

    it('should return a sorted response with best records', function (done) {
        let testURL = `/api/comment/${profileId}?sortBy=best`;
        
        api
          .get(testURL)
          
          .expect(200)
          .expect('Content-Type', 'application/json; charset=utf-8')       
          .end(function(err, res) {
            if (err) throw err;
            // console.log(res.body[0])
            assert.equal(res.body.length,2)

            assert.equal(res.body[0].commentedBy,"M MathiSudhanan")
            assert.equal(res.body[0].likesCount,3)
            const date = new Date();
            date.setDate(date.getDate() - 1);
            assert.equal(res.body[0].createdDate.toString().substring(0,10),formatDate(date))
            done()
          });
          
      });
  
      it('should return a sorted response with recent records', function (done) {
        let testURL = `/api/comment/${profileId}?sortBy=recent`;
        
        api
          .get(testURL)
          
          .expect(200)
          .expect('Content-Type', 'application/json; charset=utf-8')       
          .end(function(err, res) {
            if (err) throw err;
            // console.log(res.body[0])
            assert.equal(res.body.length,2)

            assert.equal(res.body[0].commentedBy,"Chea")
            assert.equal(res.body[0].likesCount,2)
            assert.equal(res.body[0].createdDate.toString().substring(0,10),formatDate(new Date()))

            done()
          });
          
      });

      it('should return a filtered and sorted response with recent records', function (done) {
        let testURL = `/api/comment/${profileId}?sortBy=best&zodiac=Leo`;
        
        api
          .get(testURL)
          
          .expect(200)
          .expect('Content-Type', 'application/json; charset=utf-8')       
          .end(function(err, res) {
            if (err) throw err;
            
            assert.equal(res.body.length,1)

            assert.equal(res.body[0].commentedBy,"Chea")
            assert.equal(res.body[0].likesCount,2)
            assert.equal(res.body[0].createdDate.toString().substring(0,10),formatDate(new Date()))

            done()
          });
          
      });

      it('should return a filtered and sorted response with recent single record', function (done) {
        let testURL = `/api/comment/${profileId}?sortBy=best&zodiac=Leo`;
        
        api
          .get(testURL)
          
          .expect(200)
          .expect('Content-Type', 'application/json; charset=utf-8')       
          .end(function(err, res) {
            if (err) throw err;
            
            assert.equal(res.body.length,1)

            assert.equal(res.body[0].commentedBy,"Chea")
            assert.equal(res.body[0].likesCount,2)
            assert.equal(res.body[0].createdDate.toString().substring(0,10),formatDate(new Date()))

            done()
          });
          
      });

      it('should return a filtered and sorted response with no record', function (done) {
        let testURL = `/api/comment/${profileId}?sortBy=best&zodiac=Gemini`;
        
        api
          .get(testURL)
          
          .expect(200)
          .expect('Content-Type', 'application/json; charset=utf-8')       
          .end(function(err, res) {
            if (err) throw err;
            
            assert.equal(res.body.length,0)

            
            done()
          });
          
      });


    it('should return a 404 response for comment with invalid profile Id', function (done) {
        api
          .get(`/api/comment/Test`)
          .set('Accept', 'application/json')
          .expect(404, done)
          
      });
  });