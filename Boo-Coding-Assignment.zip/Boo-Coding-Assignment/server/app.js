"use strict";

const express = require("express");
var bodyParser = require("body-parser");
var cors = require("cors");

const app = express();
const port = process.env.PORT || 3000;
const { dbConnect, dbDisconnect } = require("./DB/dbSetup.utils");
const { seedData } = require("./DB/seedData");

app.use(bodyParser.json({ limit: "30mb" }));
app.use(bodyParser.urlencoded({ limit: "30mb", extended: true }));

// set the view engine to ejs
app.set("view engine", "ejs");

// routes
app.use("/", require("./routes/profile")());
app.use("/api/profile", require("./routes/profile.apiRoutes")());
app.use("/api/comment", require("./routes/comment.apiRoutes")());
app.use("/api/like", require("./routes/like.apiRoutes")());



app.use(cors());

dbConnect()
  .then(() => {
    app.listen(port, () => console.log(`server running on port ${port}`));
    seedData()
      .then((res) => {
        console.log("Please wait for the seeding to get completed.");

        console.log("Data seeding is in progress...")
      })
      .catch((error) => {
        console.log(error.error);
      });
  })
  .catch((error) => {
    console.log(error.message);
  });


  exports.app = app;