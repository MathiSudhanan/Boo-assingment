"use strict";

const { json } = require("body-parser");
const express = require("express");
const { default: mongoose } = require("mongoose");
const {
  getProfiles,
  createProfile,
  getProfileById,
  
} = require("../controllers/profile");

const { getComments,getAllComments, addComment } = require("../controllers/comment");

const {getLikes, upsertLike}= require("../controllers/like");
const router = express.Router();
const Profile = require("../models/profile.model");

module.exports = function () {
  router.get("/", async (req, res) => {
    const users = await Profile.find({ "profile.id": 1 });

    console.log(users);

    res.render("profile_template", {
      profile: users[0],
    });
  });

  // router.get("/api/Profile", getProfiles);
  // router.get("/api/profile/:id", getProfileById);
  // router.post("/api/profile/", createProfile);

  // router.get("/api/Comment/:profileId", getComments); 
  // router.get("/api/Comment", getAllComments);  

  // router.post("/api/Comment/", addComment);

  // router.get("/api/like", getLikes);
  // router.post("/api/like", upsertLike);

  

  return router;
};
