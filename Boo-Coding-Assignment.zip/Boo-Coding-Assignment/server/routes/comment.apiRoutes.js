const express = require("express");

const router = express.Router();

const { getComments,getAllComments, addComment } = require("../controllers/comment");

module.exports =function(){
  router.get("/", getAllComments);  

  router.post("/", addComment);
  router.get("/:profileId", getComments); 

  return router;
}