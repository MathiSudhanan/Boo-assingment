const {
    getProfiles,
    createProfile,
    getProfileById,
    
  } = require("../controllers/profile");
const express = require("express");

const router = express.Router();


module.exports = function () {
router.get("/", getProfiles);
  router.post("/", createProfile);
  router.get("/:id", getProfileById);

  return router;
};