const express = require("express");

const router = express.Router();

const {getLikes, upsertLike}= require("../controllers/like");


module.exports =function(){
    router.get("/", getLikes);
    router.post("/", upsertLike);
  return router;
}