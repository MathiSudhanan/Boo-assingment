const mongoose = require('mongoose');
const { MongoMemoryServer } = require('mongodb-memory-server');

const mongoServer = MongoMemoryServer.create();

exports.dbConnect = async () => {
  const uri =await (await  mongoServer).getUri();
console.log(uri)
//   const mongooseOpts = {
//     useNewUrlParser: true,
//     useCreateIndex: true,
//     useUnifiedTopology: true,
//     useFindAndModify: false,
//   };

//   await mongoose.connect(uri, mongooseOpts);
  mongoose.set('toJSON', { virtuals: true });
  await mongoose.connect(uri, { 
    useNewUrlParser: true, 
    useUnifiedTopology: true
}, () => { 
    console.log('connected to database myDb ;)') 
});
};

exports.dbDisconnect = async () => {
  await mongoose.connection.dropDatabase();
  await mongoose.connection.close();
  await (await mongoServer).stop();
};