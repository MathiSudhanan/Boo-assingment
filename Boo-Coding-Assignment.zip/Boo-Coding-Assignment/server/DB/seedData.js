const { dbConnect, dbDisconnect } = require("./dbSetup.utils");
const Like = require("../models/like.model");
const Comment = require("../models/comment.model");
const Profile = require("../models/profile.model");




const {
  defaultUser,
  userMathi,
  userChea,
} = require("../models/testUtils/fixtures");

exports.seedData = async () => {
  const defaultUserProfile = new Profile(defaultUser);

  const savedDefaultUser = await defaultUserProfile.save();


  const userMathiProfile = new Profile(userMathi);
  await userMathiProfile.save();

  const userCheaProfile = new Profile(userChea);
  await userCheaProfile.save();

  const date = new Date();
  date.setDate(date.getDate() - 1);

  const defaultUserComments = [
    {
        title: "Tannos",
        comment: "In Avengers he played as Thannos",
        mtbi: "ESFP",
        enneagram: "6w5",
        zodiac: "Aries",
        
        createdDate: date,
      },
      {
        title: "Tannos the destroyer",
        comment: "Destroyed half of the world with single snap of finger",
        mtbi: "ESTJ",
        enneagram: "6w5",
        zodiac: "Leo",
             
      },
    ];

    const defaultLikes = [
      
        {
          isLiked:true
        }
    ];



  
  
    defaultUserComments.forEach(async (comment,index)=> {
      comment.profile = savedDefaultUser._id;
      
      if(index%2===0)
      {
        comment.commentedBy = userMathiProfile._id
      }
      else{
        comment.commentedBy = userCheaProfile._id

      }
      
      const commentNew = new Comment(comment);
      
      try {
        await commentNew.save();
    
        const profile = await Profile.findByIdAndUpdate(
          savedDefaultUser._id,
          {
            $push: { comments: commentNew._id },
          },
          { new: true, useFindAndModify: false }
        );
        }
        catch(error)
        {
          console.log({error: error.message});
        }
    });
    setTimeout(async () => {
      
    
    const commentsGet = await Comment.find();
    const profiles = await Profile.find();

    
    for (let cIndex = 0; cIndex < commentsGet.length; cIndex++) {
        let comment = commentsGet[cIndex];
        for(let lIndex = 0; lIndex<3;lIndex++)
        {
          const like = defaultLikes[0];
          like.likedBy = profiles[lIndex]._id;
          if(cIndex===0 || (cIndex===1 && lIndex<2))
          {
            like.comment = comment._id;
            const likeObj = new Like(like);
            const savedLike = await likeObj.save();

            const ccomment = await Comment.findByIdAndUpdate(
              comment._id,
              {
                $push: { likes: savedLike._id },
              },
              { new: true, useFindAndModify: false }
            );
          }
        }
        
      }
      console.log("Data seeding completed");
    
  }, 6000);
    
};
