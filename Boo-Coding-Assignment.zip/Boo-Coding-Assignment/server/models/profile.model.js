const mongoose = require("mongoose");
const { Schema } = mongoose;

const ProfileSchema = new Schema({
  
  name: {
    type:String,
    required:[true,"Name is required."]
   }, //"A Martinez",
  description: String,
  mbti: String,
  enneagram: String,
  variant: String,
  tritype: Number,
  socionics: String,
  sloan: String,
  psyche: String,
  image: String,
  comments: [{ type: Schema.Types.ObjectId, ref: "Comment" }],
});

module.exports = mongoose.model("Profile", ProfileSchema);
