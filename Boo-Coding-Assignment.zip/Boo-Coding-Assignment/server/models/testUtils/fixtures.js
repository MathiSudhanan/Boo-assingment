exports.defaultUser = {
  name: "A Martinez",
  description: "Adolph Larrue Martinez III.",
  mbti: "ISFJ",
  enneagram: "9w3",
  variant: "sp/so",
  tritype: 725,
  socionics: "SEE",
  sloan: "RCOEN",
  psyche: "FEVL",
  image: "https://soulverse.boo.world/images/1.png",
  // comments: [
  //   {
  //     title: "Tannos",
  //     comment: "In Avengers he played as Thannos",
  //     mtbi: "ESFP",
  //     enneagram: "6w5",
  //     zodiac: "Aries",
  //     commentedBy: "Chea",
  //     createdDate: new Date(),
  //   },
  // ],
};

exports.userMathi = {
  name: "M MathiSudhanan",
  description: "Adolph Larrue Martinez III.",
  mbti: "ISFJ",
  enneagram: "9w3",
  variant: "sp/so",
  tritype: 725,
  socionics: "SEE",
  sloan: "RCOEN",
  psyche: "FEVL",
  image: "https://soulverse.boo.world/images/2.png",
};

exports.userChea = {
  name: "Chea",
  description: "Adolph Larrue Martinez III.",
  mbti: "ISFJ",
  enneagram: "9w3",
  variant: "sp/so",
  tritype: 725,
  socionics: "SEE",
  sloan: "RCOEN",
  psyche: "FEVL",
  image: "https://soulverse.boo.world/images/3.png",
};
