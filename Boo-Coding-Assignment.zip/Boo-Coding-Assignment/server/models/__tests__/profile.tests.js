const Profile = require("../profile.model.js");
const { defaultUser, userMathi, userChea } = require("../testUtils/fixtures");
const {
  validateNotEmpty,
  validateStringEquality,
  validateMongoDuplicationError,
  validateEquality,
} = require("../testUtils/validator");
const { dbConnect, dbDisconnect } = require("../../DB/dbSetup.utils");

beforeAll(async () => {
  jest.setTimeout(30000);
  dbConnect();
});
afterAll(async () => dbDisconnect());
describe("Profile Model Test Suite", () => {
  test("should validate saving a default profile successfully", async () => {
    const validUserProfile = new Profile(defaultUser);

    const savedUserProfile = await validUserProfile.save();

    // const pro = await Profile.find({_id:savedUserProfile._id});

    // console.log(pro);
    validateNotEmpty(savedUserProfile);
    validateStringEquality(savedUserProfile.name, defaultUser.name);
    validateStringEquality(savedUserProfile.mbti, defaultUser.mbti);
    validateStringEquality(savedUserProfile.psyche, defaultUser.psyche);
    validateStringEquality(savedUserProfile.enneagram, defaultUser.enneagram);
    validateStringEquality(savedUserProfile.variant, defaultUser.variant);
    validateEquality(savedUserProfile.tritype, defaultUser.tritype);
  }, 60000);

  test("should validate saving a userMathi profile successfully", async () => {
    const validUserProfile = new Profile(userMathi);
    const savedUserProfile = await validUserProfile.save();
    console.log(savedUserProfile);
    validateNotEmpty(savedUserProfile);
    validateStringEquality(savedUserProfile.name, userMathi.name);
    validateStringEquality(savedUserProfile.mbti, userMathi.mbti);
    validateStringEquality(savedUserProfile.psyche, userMathi.psyche);
    validateStringEquality(savedUserProfile.enneagram, userMathi.enneagram);
    validateStringEquality(savedUserProfile.variant, userMathi.variant);
    validateEquality(savedUserProfile.tritype, userMathi.tritype);
  });

  test("should validate saving a userChea profile successfully", async () => {
    const validUserProfile = new Profile(userChea);
    const savedUserProfile = await validUserProfile.save();

    validateNotEmpty(savedUserProfile);
    validateStringEquality(savedUserProfile.name, userChea.name);
    validateStringEquality(savedUserProfile.mbti, userChea.mbti);
    validateStringEquality(savedUserProfile.psyche, userChea.psyche);
    validateStringEquality(savedUserProfile.enneagram, userChea.enneagram);
    validateStringEquality(savedUserProfile.variant, userChea.variant);
    validateEquality(savedUserProfile.tritype, userChea.tritype);
  });

  //   test('should validate MongoError duplicate error with code 11000', async () => {
  //     expect.assertions(4);
  //     const validStudentUser = new Profile({
  //       local: fakeProfileData,
  //       role: fakeProfileData.role,
  //     });

  //     try {
  //       await validStudentUser.save();
  //     } catch (error) {
  //       const { name, code } = error;
  //       validateMongoDuplicationError(name, code);
  //     }
  //   });
});
