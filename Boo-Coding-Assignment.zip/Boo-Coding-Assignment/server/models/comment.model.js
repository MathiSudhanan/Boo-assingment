const mongoose = require("mongoose");
const { Schema } = mongoose;

const CommentSchema = new Schema({
  title:  {
    type:String,
    required: [true,"Title is required."]
  },
  comment: {
    type:String,
    required: [true,"Comment is required."]
  },
  mtbi: String,
  enneagram: String,
  zodiac: String,
  commentedBy: { type: Schema.Types.ObjectId, ref: "Profile" },
  createdDate: {
    type: Date,
    default: Date.now,
  },
  likes: [{ type: Schema.Types.ObjectId, ref: "Like" }],
  profile: { type: Schema.Types.ObjectId, ref: "Profile" },
  
},{ toJSON: { virtuals: true }});

CommentSchema.virtual('likesCount',{
 
  ref: 'Like',
    localField: '_id',
    foreignField: 'comment',
    count: true
})
module.exports = mongoose.model("Comment", CommentSchema);
