const mongoose = require("mongoose");
const { Schema } = mongoose;

const LikeSchema = new Schema({
  isLiked: Boolean,
  likedBy: { type: Schema.Types.ObjectId, ref: "Profile" },
  comment: { type: Schema.Types.ObjectId, ref: "Comment" },
});

module.exports = mongoose.model("Like", LikeSchema);
